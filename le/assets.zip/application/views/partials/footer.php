
</div> <!--div container-->
<div id="fott">


    <h6><small>  &copy; 2014 ZZWT Kraków ::
    
        Page rendered in <strong>{elapsed_time}</strong> seconds
        
        </small></h6>
</div>

</body>
</html>

    
