<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo CI_VERSION ." codeigniter ::j query-1.8.2 ::  Bootstrap v2.2.1 <br>";
?>

    <a href="<?php echo  site_url('setup/get_all_cours');?>"    class="btn btn-danger">wszystkie kursy </a>
    <a href="<?php echo  site_url('setup/nowy_kurs');?>"        class="btn btn-danger">dodaj kurs </a>
    
    <a href="<?php echo  site_url('setup/edit_serv');?>"        class="btn btn-danger">serwery </a>
    
    <a href="<?php echo  site_url('setup/edit_jw');?>"          class="btn btn-danger">jednostki </a>
    <a href="<?php echo  site_url('setup/a_dmins');?>"          class="btn btn-danger">użytkownicy </a>
    <a href="<?php echo  site_url('setup/edit_cat');?>"         class="btn btn-danger">kategorie </a>
    <a href="<?php echo  site_url('setup/s_artykul');?>"         class="btn btn-danger">artykuł 1 strona </a>
    
    
    <br><br><br>                
    
    